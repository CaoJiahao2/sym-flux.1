"""Camera utilities for SynCamVideo-Dataset.

This module only reads metadata from SynCamVideo-Dataset. It never writes into the
original dataset directory.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Dict, Iterable, List, Sequence

import numpy as np


Number = float | int


def parse_extrinsic_string(value: str | Sequence[Number]) -> np.ndarray:
    """Parse one camera extrinsic into a 4x4 float32 matrix.

    The dataset JSON stores matrices as strings such as:
        "[r11 r12 r13 tx] [r21 r22 r23 ty] [r31 r32 r33 tz]"

    This function also accepts a flat list of 12 or 16 numbers for robustness.
    """
    if isinstance(value, str):
        nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", value)]
    else:
        nums = [float(x) for x in value]

    arr = np.asarray(nums, dtype=np.float32)

    if arr.size == 12:
        mat = arr.reshape(3, 4)
        mat = np.vstack([mat, np.array([[0, 0, 0, 1]], dtype=np.float32)])
    elif arr.size == 16:
        mat = arr.reshape(4, 4)
    else:
        raise ValueError(f"Expected 12 or 16 numbers for extrinsic, got {arr.size}: {value}")

    return mat.astype(np.float32)


def load_scene_extrinsics(camera_extrinsics_json: str | Path) -> Dict[str, Dict[str, np.ndarray]]:
    """Load scene camera extrinsics.

    Returns:
        dict[frame_key][cam_id] = 4x4 matrix
    """
    camera_extrinsics_json = Path(camera_extrinsics_json)
    with camera_extrinsics_json.open("r", encoding="utf-8") as f:
        raw = json.load(f)

    parsed: Dict[str, Dict[str, np.ndarray]] = {}
    for frame_key, cam_dict in raw.items():
        parsed[frame_key] = {}
        for cam_id, matrix_like in cam_dict.items():
            parsed[frame_key][cam_id] = parse_extrinsic_string(matrix_like)
    return parsed


def matrix_to_12d(mat: np.ndarray) -> List[float]:
    """Convert 4x4 or 3x4 matrix to flattened 12D [R|t]."""
    mat = np.asarray(mat, dtype=np.float32)
    if mat.shape == (4, 4):
        mat = mat[:3, :4]
    elif mat.shape != (3, 4):
        raise ValueError(f"Expected matrix shape (4,4) or (3,4), got {mat.shape}")
    return mat.reshape(-1).astype(float).tolist()


def normalize_extrinsics_to_anchor(
    mats: Sequence[np.ndarray],
    anchor_index: int = 0,
    convention: str = "w2c",
) -> np.ndarray:
    """Normalize cameras by setting one camera as the global reference.

    Args:
        mats: list of 4x4 extrinsic matrices.
        anchor_index: the camera used as the local/global coordinate reference.
        convention:
            - "w2c": matrix maps world coordinates to camera coordinates.
                     relative_i = E_i @ inv(E_anchor)
            - "c2w": matrix maps camera coordinates to world coordinates.
                     relative_i = inv(E_anchor) @ E_i

    Returns:
        [N, 12] flattened relative camera matrices.
    """
    if convention not in {"w2c", "c2w", "none"}:
        raise ValueError(f"Unknown convention: {convention}")

    mats = [np.asarray(m, dtype=np.float32) for m in mats]

    if convention == "none":
        return np.stack([np.asarray(matrix_to_12d(m), dtype=np.float32) for m in mats], axis=0)

    anchor = mats[anchor_index]
    inv_anchor = np.linalg.inv(anchor)

    rels = []
    for E in mats:
        if convention == "w2c":
            rel = E @ inv_anchor
        else:  # c2w
            rel = inv_anchor @ E
        rels.append(rel[:3, :4].reshape(-1))

    return np.stack(rels, axis=0).astype(np.float32)


def rotation_angle_deg(Ea: np.ndarray, Eb: np.ndarray) -> float:
    """Rotation angle in degrees between two camera rotations.

    This is used only for sampling/curriculum. It does not modify the dataset.
    """
    Ra = np.asarray(Ea, dtype=np.float32)[:3, :3]
    Rb = np.asarray(Eb, dtype=np.float32)[:3, :3]
    R = Ra.T @ Rb
    cos = (float(np.trace(R)) - 1.0) / 2.0
    cos = max(-1.0, min(1.0, cos))
    return math.degrees(math.acos(cos))


def max_pairwise_rotation_angle_deg(mats: Sequence[np.ndarray]) -> float:
    """Maximum pairwise camera rotation angle in one selected view group."""
    if len(mats) < 2:
        return 0.0
    max_angle = 0.0
    for i in range(len(mats)):
        for j in range(i + 1, len(mats)):
            max_angle = max(max_angle, rotation_angle_deg(mats[i], mats[j]))
    return float(max_angle)
